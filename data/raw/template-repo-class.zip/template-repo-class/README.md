# Data Science Project 

## Project Description

The purpose of this project is to understand the behavior of...

## Getting Started

```
pip install -r requirements
```

## Resources

[Kaggle.com](kaggle)

